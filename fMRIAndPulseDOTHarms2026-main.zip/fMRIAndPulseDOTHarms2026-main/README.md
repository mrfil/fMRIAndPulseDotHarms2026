Reference code files for paper. 
Starting from global pulse-DOT waveforms, how measures were computed
After having measures, running the final statistics on the data
The automated quality check for the PPG files
